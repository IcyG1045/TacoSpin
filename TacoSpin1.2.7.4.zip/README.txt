This is an app created by ScottyG.

Bruh it's a taco that spins
